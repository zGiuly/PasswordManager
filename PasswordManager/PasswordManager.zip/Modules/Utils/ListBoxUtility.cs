﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using static PasswordManager.Modules.Password.PasswordManager;

namespace PasswordManager.Modules.Utils
{
    public static class ListBoxUtility
    {
        public static async Task LoadAccountsToListBoxAsync(ListBox listBox, List<Account> accounts, Password.PasswordManager passwordManager)
        {
            await Task.Run(() =>
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
                    foreach (var account in accounts)
                    {
                        var accountItem = CreateAccountListBoxItem(account, passwordManager);
                        listBox.Items.Add(accountItem);
                    }
                });
            });
        }

        public static async Task<List<T>> GetAllItemsAsync<T>(ListBox listBox)
        {
            return await Task.Run(() =>
            {
                return Application.Current.Dispatcher.Invoke(() =>
                {
                    var items = new List<T>();
                    foreach (var item in listBox.Items)
                    {
                        if (item is T typedItem)
                        {
                            items.Add(typedItem);
                        }
                    }
                    return items;
                });
            });
        }

        private static ListBoxItem CreateAccountListBoxItem(Account account, Password.PasswordManager passwordManager)
        {
            var stackPanel = new StackPanel { Orientation = Orientation.Horizontal };

            var accountInfoTextBlock = new TextBlock
            {
                Text = $"Username: {account.Username}, Password: {account.Password}, Link: {account.Link}, Email: {account.Email}",
                Margin = new Thickness(0, 0, 10, 0),
                TextWrapping = TextWrapping.Wrap
            };

            var removeButton = new Button { Content = "Rimuovi", Background = Brushes.Red, Foreground = Brushes.White, Margin = new Thickness(0, 0, 5, 0) };
            var copyButton = new Button { Content = "Copia", Background = Brushes.Green, Foreground = Brushes.White };

            removeButton.Click += async (sender, e) =>
            {
                if (sender is Button button && button.DataContext is ListBoxItem listBoxItem)
                {

                    var result = MessageBox.Show("Sei sicuro di voler cancellare questo account?", "Conferma cancellazione", MessageBoxButton.YesNo, MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        var listBox = listBoxItem.Parent as ListBox;

                        if (listBox != null)
                        {
                            listBox.Items.Remove(listBoxItem);
                        }

                        passwordManager.RemoveAccount(account);
                    }
                }
            };

            copyButton.Click += (sender, e) =>
            {
                if (sender is Button button)
                {
                    var listBoxItem = button.DataContext as ListBoxItem;
                    if (listBoxItem != null)
                    {
                        var accountInfo = accountInfoTextBlock.Text;
                        Clipboard.SetText(accountInfo);
                        MessageBox.Show("Dati copiati negli Appunti.");

                        Task.Delay(TimeSpan.FromSeconds(10)).ContinueWith((t) =>
                        {
                            Application.Current.Dispatcher.Invoke(() =>
                            {
                                if (Clipboard.ContainsText())
                                {
                                    Clipboard.Clear();
                                    MessageBox.Show("Dati rimossi dalla clipboard.");
                                }
                            });
                        });
                    }
                }
            };

            stackPanel.Children.Add(accountInfoTextBlock);
            stackPanel.Children.Add(removeButton);
            stackPanel.Children.Add(copyButton);

            var accountItem = new ListBoxItem { Content = stackPanel };

            removeButton.DataContext = accountItem;
            copyButton.DataContext = accountItem;

            return accountItem;
        }
    }
}
