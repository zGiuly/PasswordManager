﻿using PasswordManager.Modules.Utils;
using PasswordManager.Modules.View;
using System.Windows;

namespace PasswordManager
{
    /// <summary>
    /// Logica di interazione per Password_list.xaml
    /// </summary>
    public partial class Password_list : Window
    {
        public Password_list()
        {
            InitializeComponent();
            MainViewModel model = new MainViewModel();
            DataContext = model;

            var passwordManager = model._passwordManager;

            var accountList = passwordManager.LoadAccounts();

            if (accountList != null && accountList.Count > 0)
            {
                ListBoxUtility.LoadAccountsToListBoxAsync(lstAccounts, accountList, passwordManager);
            }
        }
    }
}
