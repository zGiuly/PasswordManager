﻿using System.Windows;

namespace PasswordManager
{
    /// <summary>
    /// Logica di interazione per CreatePassword.xaml
    /// </summary>
    public partial class CreatePassword : Window
    {
        public CreatePassword()
        {
            InitializeComponent();
        }
    }
}
